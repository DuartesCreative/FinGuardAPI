/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,jsx}"],
  safelist: [
    "bg-violet-300",
    "bg-rose-300",
    "bg-amber-300",
    "bg-emerald-300",
  ],
  theme: {
    extend: {},
  },
  plugins: [],
};
