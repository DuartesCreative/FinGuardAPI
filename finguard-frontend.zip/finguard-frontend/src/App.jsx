import { useState, useEffect, useCallback, useMemo } from "react";
import {
  Home, List, Tag, LineChart as LineChartIcon, LogOut, Plus, X, ArrowUpRight, ArrowDownRight,
  Loader2, AlertCircle, ChevronRight, Settings2, Trash2, Pencil, Target, SlidersHorizontal, Sparkles,
} from "lucide-react";
import {
  ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid,
  PieChart, Pie, Cell, Legend,
} from "recharts";

const GLOBAL_CSS = `
@import url('https://fonts.googleapis.com/css2?family=Outfit:wght@400;500;600;700;800&family=Nunito:wght@400;600;700;800&display=swap');

.fg-root, .fg-root * { font-family: 'Nunito', sans-serif; }
.fg-display { font-family: 'Outfit', sans-serif; }

.glass-bg { position: fixed; inset: 0; z-index: -2;
  background: linear-gradient(135deg, #eef2ff 0%, #fdf4ff 45%, #fff7ed 100%); }
.blob { position: fixed; border-radius: 9999px; filter: blur(70px); z-index: -1; animation: drift 14s ease-in-out infinite; }
@keyframes drift { 0%,100% { transform: translate(0,0) scale(1); } 50% { transform: translate(30px,-24px) scale(1.06); } }

.glass-card { background: rgba(255,255,255,0.55); backdrop-filter: blur(18px) saturate(160%); -webkit-backdrop-filter: blur(18px) saturate(160%);
  border: 1px solid rgba(255,255,255,0.7); border-radius: 24px; box-shadow: 0 8px 30px rgba(88,60,180,0.10); }
.glass-panel { background: rgba(255,255,255,0.45); backdrop-filter: blur(24px) saturate(160%); -webkit-backdrop-filter: blur(24px) saturate(160%); }
.glass-strong { background: rgba(255,255,255,0.75); backdrop-filter: blur(20px); -webkit-backdrop-filter: blur(20px); }

.glass-input { width: 100%; background: rgba(255,255,255,0.65); border: 1px solid rgba(255,255,255,0.9); border-radius: 14px;
  padding: 9px 13px; font-size: 14px; font-weight: 600; outline: none; transition: box-shadow .15s, border-color .15s; }
.glass-input:focus { border-color: #a78bfa; box-shadow: 0 0 0 3px rgba(167,139,250,0.25); }

.btn-primary { background: linear-gradient(135deg,#7C3AED,#D946EF); color: #fff; border-radius: 16px; font-weight: 700;
  box-shadow: 0 6px 20px rgba(124,58,237,0.35); transition: transform .15s ease, box-shadow .15s ease; }
.btn-primary:hover { transform: translateY(-2px); box-shadow: 0 10px 26px rgba(124,58,237,0.45); }
.btn-primary:active { transform: translateY(0); }
.btn-primary:disabled { opacity: .55; transform: none; }

.btn-glass { background: rgba(255,255,255,0.55); backdrop-filter: blur(10px); border: 1px solid rgba(255,255,255,0.85);
  border-radius: 14px; font-weight: 700; transition: transform .15s ease, background .15s ease; }
.btn-glass:hover { background: rgba(255,255,255,0.8); transform: translateY(-1px); }

.nav-item { border-radius: 14px; font-weight: 700; transition: all .15s ease; }
.nav-item-active { background: linear-gradient(135deg, rgba(124,58,237,0.9), rgba(217,70,239,0.85)); color: #fff;
  box-shadow: 0 6px 16px rgba(124,58,237,0.3); }

.goal-track { background: rgba(120,90,200,0.12); border-radius: 999px; height: 10px; overflow: hidden; }
.goal-fill { height: 100%; border-radius: 999px; background: linear-gradient(90deg,#7C3AED,#D946EF); transition: width .6s ease; }

@keyframes floaty { 0%,100% { transform: translateY(0) rotate(-2deg); } 50% { transform: translateY(-8px) rotate(2deg); } }
.mascot-float { animation: floaty 3.4s ease-in-out infinite; }
@keyframes blink { 0%, 88%, 100% { transform: scaleY(1); } 92% { transform: scaleY(0.1); } }
.mascot-eye { animation: blink 4.5s ease-in-out infinite; transform-origin: center; }

@keyframes popIn { 0% { transform: scale(.92) translateY(10px); opacity: 0; } 100% { transform: scale(1) translateY(0); opacity: 1; } }
.pop-in { animation: popIn .25s cubic-bezier(.34,1.56,.64,1) both; }
@keyframes toastIn { 0% { transform: translate(-50%, 24px); opacity: 0; } 100% { transform: translate(-50%, 0); opacity: 1; } }
.toast-in { animation: toastIn .3s cubic-bezier(.34,1.56,.64,1) both; }
`;

const money = (n, currency = "BRL") =>
  new Intl.NumberFormat("pt-BR", { style: "currency", currency }).format(n || 0);
const pct = (n) => `${n >= 0 ? "+" : ""}${n.toFixed(2)}%`;
const dateBR = (iso) =>
  new Date(iso).toLocaleDateString("pt-BR", { day: "2-digit", month: "short", year: "numeric" });
const monthLabel = (key) => {
  const [y, m] = key.split("-");
  return new Date(Number(y), Number(m) - 1, 1).toLocaleDateString("pt-BR", { month: "short" });
};

const ASSET_LABEL = { moeda: "Moeda estrangeira", fii: "Fundo imobiliário", acao: "Ação", renda_fixa: "Renda fixa", cripto: "Criptoativo" };
const ASSET_EMOJI = { moeda: "💵", fii: "🏢", acao: "📈", renda_fixa: "🏦", cripto: "🪙" };
const CHART_COLORS = ["#7C3AED", "#F59E0B", "#10B981", "#F43F5E", "#3B82F6", "#EC4899", "#84CC16"];
const GOAL_EMOJIS = ["🎯", "✈️", "🏠", "🚗", "💍", "🎓", "📱", "💻", "🐶", "🏖️"];

const GAMBLING_TOKENS = [
  "bet", "bet365", "betano", "sportingbet", "1xbet", "kto", "pixbet", "estrelabet",
  "jonbet", "blaze", "fortunetiger", "aposta", "apostas", "cassino", "casino",
  "roleta", "bingo", "poker", "tigrinho",
];
function isGamblingExpense(rawText) {
  const normalized = rawText.toLowerCase().normalize("NFD").replace(/[\u0300-\u036f]/g, "");
  const tokens = normalized.split(/[^a-z0-9]+/).filter(Boolean);
  return tokens.some((t) => GAMBLING_TOKENS.includes(t)) || normalized.includes("jogo do bicho");
}
function futureValueLump(amount, annualRatePct, years) {
  return amount * Math.pow(1 + annualRatePct / 100, years);
}
function futureValueMonthlyAnnuity(monthlyAmount, annualRatePct, months) {
  const i = annualRatePct / 100 / 12;
  if (i === 0) return monthlyAmount * months;
  return monthlyAmount * ((Math.pow(1 + i, months) - 1) / i);
}

function BackgroundBlobs() {
  return (
    <>
      <div className="glass-bg" />
      <div className="blob" style={{ width: 340, height: 340, top: -80, left: -60, background: "#c4b5fd" }} />
      <div className="blob" style={{ width: 300, height: 300, bottom: -60, right: -40, background: "#f0abfc", animationDelay: "2s" }} />
      <div className="blob" style={{ width: 220, height: 220, top: "40%", right: "8%", background: "#fcd34d", opacity: 0.5, animationDelay: "4s" }} />
      <div className="blob" style={{ width: 200, height: 200, bottom: "15%", left: "10%", background: "#6ee7b7", opacity: 0.45, animationDelay: "1s" }} />
    </>
  );
}

function Mascot({ mood = "neutral", size = 72 }) {
  const mouth = {
    happy: "M 26 46 Q 36 56 46 46",
    neutral: "M 27 48 Q 36 48 45 48",
    worried: "M 27 50 Q 36 42 45 50",
  }[mood];
  const brow = mood === "worried" ? -2 : mood === "happy" ? 2 : 0;
  const gid = "mascotGrad";
  return (
    <svg width={size} height={size} viewBox="0 0 72 80" className="mascot-float">
      <defs>
        <linearGradient id={gid} x1="0" y1="0" x2="1" y2="1">
          <stop offset="0%" stopColor="#8B5CF6" />
          <stop offset="100%" stopColor="#D946EF" />
        </linearGradient>
      </defs>
      <path d="M36 2 L68 14 V38 C68 58 54 72 36 78 C18 72 4 58 4 38 V14 Z" fill={`url(#${gid})`} stroke="#5B21B6" strokeWidth="2" strokeLinejoin="round" opacity="0.92" />
      <g>
        <ellipse className="mascot-eye" cx="27" cy="34" rx="4.5" ry="6" fill="#fff" transform={`rotate(${brow} 27 34)`} />
        <ellipse className="mascot-eye" cx="45" cy="34" rx="4.5" ry="6" fill="#fff" transform={`rotate(${-brow} 45 34)`} />
      </g>
      <path d={mouth} stroke="#fff" strokeWidth="3" fill="none" strokeLinecap="round" />
    </svg>
  );
}

function Toast({ text }) {
  if (!text) return null;
  return (
    <div className="fixed bottom-24 md:bottom-6 left-1/2 z-50 toast-in">
      <div className="glass-strong border border-white/80 rounded-2xl px-4 py-2.5 flex items-center gap-2 text-sm font-bold text-neutral-800 shadow-lg whitespace-nowrap">
        <Sparkles className="w-4 h-4 text-violet-500" />
        {text}
      </div>
    </div>
  );
}

function useApi(apiUrl, token) {
  return useCallback(
    async (path, opts = {}) => {
      const headers = { ...(opts.headers || {}) };
      if (token) headers["Authorization"] = `Bearer ${token}`;
      const res = await fetch(apiUrl + path, { ...opts, headers });
      if (res.status === 204) return null;
      let data = null;
      try { data = await res.json(); } catch (_) { data = null; }
      if (!res.ok) {
        const detail = (data && (data.detail || JSON.stringify(data))) || `Erro ${res.status}`;
        throw new Error(typeof detail === "string" ? detail : "Não foi possível completar a ação.");
      }
      return data;
    },
    [apiUrl, token]
  );
}

export default function FinGuardApp() {
  const [apiUrl, setApiUrl] = useState("http://localhost:8000");
  const [showSettings, setShowSettings] = useState(false);

  const [token, setToken] = useState(null);
  const [user, setUser] = useState(null);

  const [screen, setScreen] = useState("dashboard");
  const [authMode, setAuthMode] = useState("login");

  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [fullName, setFullName] = useState("");

  const [categories, setCategories] = useState([]);
  const [transactions, setTransactions] = useState([]);
  const [investments, setInvestments] = useState([]);
  const [goals, setGoals] = useState([]);

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [toast, setToast] = useState(null);

  const [showAddTx, setShowAddTx] = useState(false);
  const [showAddCat, setShowAddCat] = useState(false);
  const [showAddInv, setShowAddInv] = useState(false);
  const [editingInv, setEditingInv] = useState(null);
  const [showAddGoal, setShowAddGoal] = useState(false);
  const [contributingGoal, setContributingGoal] = useState(null);
  const [gamblingNudge, setGamblingNudge] = useState(null);

  const api = useApi(apiUrl, token);

  useEffect(() => {
    if (!toast) return;
    const t = setTimeout(() => setToast(null), 2400);
    return () => clearTimeout(t);
  }, [toast]);

  const loadData = useCallback(async () => {
    setLoading(true);
    setError("");
    try {
      const [cats, txs, invs, gls] = await Promise.all([
        api("/categories/"), api("/transactions/"), api("/investments/"), api("/goals/"),
      ]);
      setCategories(cats);
      setTransactions(txs);
      setInvestments(invs);
      setGoals(gls);
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }, [api]);

  useEffect(() => { if (token) loadData(); }, [token, loadData]);

  async function handleAuth(e) {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      if (authMode === "register") {
        const r = await fetch(apiUrl + "/auth/register", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ email, password, full_name: fullName || undefined }),
        });
        if (!r.ok) {
          const d = await r.json().catch(() => ({}));
          throw new Error(d.detail || "Não foi possível criar a conta.");
        }
      }
      const form = new URLSearchParams();
      form.append("grant_type", "password");
      form.append("username", email);
      form.append("password", password);

      const res = await fetch(apiUrl + "/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: form,
      });
      const data = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(data.detail || "E-mail ou senha incorretos.");

      setToken(data.access_token);
      const me = await fetch(apiUrl + "/users/me", { headers: { Authorization: `Bearer ${data.access_token}` } }).then((r) => r.json());
      setUser(me);
      setScreen("dashboard");
      setToast(`Bem-vindo(a), ${me.full_name || me.email.split("@")[0]}`);
    } catch (e) {
      setError(e.message === "Failed to fetch" ? "Não consegui conectar no backend. Confirme que a API está rodando e a URL está certa." : e.message);
    } finally {
      setLoading(false);
    }
  }

  function handleLogout() {
    setToken(null); setUser(null); setCategories([]); setTransactions([]); setInvestments([]); setGoals([]);
    setEmail(""); setPassword(""); setScreen("dashboard");
  }

  async function createCategory(name, type) {
    setError("");
    try {
      const cat = await api("/categories/", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ name, type }) });
      setCategories((c) => [...c, cat]);
      setShowAddCat(false);
      setToast("Categoria criada");
    } catch (e) { setError(e.message); }
  }

  async function createTransaction(payload) {
    setError("");
    try {
      const tx = await api("/transactions/", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload) });
      setTransactions((t) => [tx, ...t]);
      setShowAddTx(false);
      setToast("Transação salva");

      if (payload.type === "expense") {
        const catName = categories.find((c) => c.id === payload.category_id)?.name || "";
        const text = `${payload.description || ""} ${catName}`;
        if (isGamblingExpense(text)) {
          setGamblingNudge({ amount: payload.amount, label: payload.description || catName });
        }
      }
    } catch (e) { setError(e.message); }
  }

  async function createInvestment(payload) {
    setError("");
    try {
      const inv = await api("/investments/", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload) });
      setInvestments((i) => [inv, ...i]);
      setShowAddInv(false);
      setToast("Ativo adicionado");
    } catch (e) { setError(e.message); }
  }

  async function updateInvestmentPrice(id, current_price) {
    setError("");
    try {
      const inv = await api(`/investments/${id}/price`, { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ current_price }) });
      setInvestments((list) => list.map((i) => (i.id === id ? inv : i)));
      setEditingInv(null);
      setToast("Cotação atualizada");
    } catch (e) { setError(e.message); }
  }

  async function deleteInvestment(id) {
    setError("");
    try {
      await api(`/investments/${id}`, { method: "DELETE" });
      setInvestments((list) => list.filter((i) => i.id !== id));
      setToast("Ativo removido");
    } catch (e) { setError(e.message); }
  }

  async function createGoal(payload) {
    setError("");
    try {
      const goal = await api("/goals/", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(payload) });
      setGoals((g) => [goal, ...g]);
      setShowAddGoal(false);
      setToast("Meta criada");
    } catch (e) { setError(e.message); }
  }

  async function contributeToGoal(id, amount) {
    setError("");
    try {
      const goal = await api(`/goals/${id}/contribute`, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ amount }) });
      setGoals((list) => list.map((g) => (g.id === id ? goal : g)));
      setContributingGoal(null);
      setToast(goal.current_amount >= goal.target_amount ? "Meta atingida! 🎉" : "Aporte registrado");
    } catch (e) { setError(e.message); }
  }

  async function deleteGoal(id) {
    setError("");
    try {
      await api(`/goals/${id}`, { method: "DELETE" });
      setGoals((list) => list.filter((g) => g.id !== id));
      setToast("Meta removida");
    } catch (e) { setError(e.message); }
  }

  const income = transactions.filter((t) => t.type === "income").reduce((s, t) => s + t.amount, 0);
  const expense = transactions.filter((t) => t.type === "expense").reduce((s, t) => s + t.amount, 0);
  const balance = income - expense;

  const invested = investments.reduce((s, i) => s + i.quantity * i.avg_price, 0);
  const currentValue = investments.reduce((s, i) => s + i.quantity * i.current_price, 0);
  const gain = currentValue - invested;
  const gainPct = invested > 0 ? (gain / invested) * 100 : 0;

  const mood = balance > 0 ? "happy" : balance < 0 ? "worried" : "neutral";

  const monthlyData = useMemo(() => {
    const map = {};
    transactions.forEach((t) => {
      const key = t.occurred_at.slice(0, 7);
      if (!map[key]) map[key] = { key, income: 0, expense: 0 };
      map[key][t.type] += t.amount;
    });
    return Object.values(map).sort((a, b) => a.key.localeCompare(b.key)).slice(-6).map((m) => ({ ...m, label: monthLabel(m.key) }));
  }, [transactions]);

  const expenseByCategory = useMemo(() => {
    const map = {};
    transactions.filter((t) => t.type === "expense").forEach((t) => {
      const cat = categories.find((c) => c.id === t.category_id);
      const name = cat?.name || "Sem categoria";
      map[name] = (map[name] || 0) + t.amount;
    });
    return Object.entries(map).map(([name, value]) => ({ name, value }));
  }, [transactions, categories]);

  const allocationData = useMemo(() => {
    const map = {};
    investments.forEach((i) => {
      const label = ASSET_LABEL[i.asset_type] || i.asset_type;
      map[label] = (map[label] || 0) + i.quantity * i.current_price;
    });
    return Object.entries(map).map(([name, value]) => ({ name, value }));
  }, [investments]);

  const NAV = [
    { id: "dashboard", label: "Início", icon: Home },
    { id: "transactions", label: "Transações", icon: List },
    { id: "goals", label: "Metas", icon: Target },
    { id: "investments", label: "Investimentos", icon: LineChartIcon },
    { id: "categories", label: "Categorias", icon: Tag },
  ];

  if (!token) {
    return (
      <div className="fg-root min-h-screen flex flex-col items-center justify-center px-6 py-10 relative overflow-hidden">
        <style>{GLOBAL_CSS}</style>
        <BackgroundBlobs />
        <div className="w-full max-w-sm relative z-10">
          <div className="flex flex-col items-center mb-6">
            <Mascot mood="happy" size={80} />
            <span className="fg-display text-2xl font-bold tracking-tight text-neutral-900 mt-3">FinGuard</span>
            <span className="text-xs text-neutral-500 font-semibold">seu guardião financeiro</span>
          </div>

          <div className="glass-card p-6 pop-in">
            <div className="flex bg-white/40 rounded-xl p-1 mb-6 border border-white/70">
              <button onClick={() => { setAuthMode("login"); setError(""); }}
                className={`flex-1 text-sm font-bold py-2 rounded-lg transition-all ${authMode === "login" ? "nav-item-active" : "text-neutral-500"}`}>
                Entrar
              </button>
              <button onClick={() => { setAuthMode("register"); setError(""); }}
                className={`flex-1 text-sm font-bold py-2 rounded-lg transition-all ${authMode === "register" ? "nav-item-active" : "text-neutral-500"}`}>
                Criar conta
              </button>
            </div>

            <form onSubmit={handleAuth} className="space-y-4">
              {authMode === "register" && (
                <Field label="Nome"><input value={fullName} onChange={(e) => setFullName(e.target.value)} className="glass-input" placeholder="Arthur" /></Field>
              )}
              <Field label="E-mail"><input type="email" required value={email} onChange={(e) => setEmail(e.target.value)} className="glass-input" placeholder="arthur@finguard.com" /></Field>
              <Field label="Senha"><input type="password" required value={password} onChange={(e) => setPassword(e.target.value)} className="glass-input" placeholder="••••••••" /></Field>

              {error && <ErrorBanner text={error} />}

              <button type="submit" disabled={loading} className="btn-primary w-full text-sm py-3 flex items-center justify-center gap-2">
                {loading && <Loader2 className="w-4 h-4 animate-spin" />}
                {authMode === "login" ? "Entrar" : "Criar conta"}
              </button>
            </form>
          </div>

          <button onClick={() => setShowSettings((s) => !s)} className="mt-4 text-xs text-neutral-500 font-bold hover:text-neutral-800 flex items-center gap-1 mx-auto">
            <Settings2 className="w-3.5 h-3.5" /> URL da API
          </button>
          {showSettings && <input value={apiUrl} onChange={(e) => setApiUrl(e.target.value)} className="glass-input mt-2 font-mono text-xs" />}
        </div>
      </div>
    );
  }

  return (
    <div className="fg-root min-h-screen flex relative">
      <style>{GLOBAL_CSS}</style>
      <BackgroundBlobs />

      <aside className="hidden md:flex flex-col w-60 glass-panel border-r border-white/50 px-4 py-6">
        <div className="flex items-center gap-2 px-1 mb-8">
          <Mascot mood={mood} size={38} />
          <span className="fg-display font-bold tracking-tight text-neutral-900 text-lg">FinGuard</span>
        </div>
        <nav className="space-y-1.5 flex-1">
          {NAV.map(({ id, label, icon: Icon }) => (
            <button key={id} onClick={() => setScreen(id)}
              className={`nav-item w-full flex items-center gap-3 px-3 py-2.5 text-sm ${screen === id ? "nav-item-active" : "text-neutral-600 hover:bg-white/40"}`}>
              <Icon className="w-4.5 h-4.5" />
              {label}
            </button>
          ))}
        </nav>
        <div className="pt-4 border-t border-white/50">
          <p className="text-xs text-neutral-500 px-2 mb-2 truncate font-bold">{user?.email}</p>
          <button onClick={handleLogout} className="nav-item w-full flex items-center gap-3 px-3 py-2 text-sm text-neutral-500 hover:bg-white/40 hover:text-rose-600">
            <LogOut className="w-4 h-4" /> Sair
          </button>
        </div>
      </aside>

      <div className="flex-1 flex flex-col min-w-0">
        <header className="md:hidden flex items-center justify-between px-4 py-3 glass-panel border-b border-white/50">
          <div className="flex items-center gap-2">
            <Mascot mood={mood} size={32} />
            <span className="fg-display font-bold text-neutral-900">FinGuard</span>
          </div>
          <button onClick={handleLogout} className="text-neutral-500"><LogOut className="w-5 h-5" /></button>
        </header>

        <main className="flex-1 overflow-y-auto px-4 md:px-10 py-6 md:py-8 pb-24 md:pb-8 max-w-3xl w-full mx-auto">
          {error && <ErrorBanner text={error} className="mb-4" />}
          {loading && transactions.length === 0 && investments.length === 0 && (
            <div className="flex items-center gap-2 text-neutral-500 text-sm py-8 justify-center font-bold">
              <Loader2 className="w-4 h-4 animate-spin" /> Carregando...
            </div>
          )}

          {screen === "dashboard" && (
            <Dashboard income={income} expense={expense} balance={balance} currentValue={currentValue} gain={gain} gainPct={gainPct}
              transactions={transactions} categories={categories} goals={goals} onAddTx={() => setShowAddTx(true)} mood={mood}
              monthlyData={monthlyData} expenseByCategory={expenseByCategory} />
          )}
          {screen === "transactions" && (
            <TransactionsScreen transactions={transactions} categories={categories} onAddTx={() => setShowAddTx(true)} />
          )}
          {screen === "goals" && (
            <GoalsScreen goals={goals} onAdd={() => setShowAddGoal(true)} onContribute={(g) => setContributingGoal(g)} onDelete={deleteGoal} />
          )}
          {screen === "investments" && (
            <InvestmentsScreen investments={investments} invested={invested} currentValue={currentValue} gain={gain} gainPct={gainPct}
              onAdd={() => setShowAddInv(true)} onEditPrice={(inv) => setEditingInv(inv)} onDelete={deleteInvestment} allocationData={allocationData} />
          )}
          {screen === "categories" && <CategoriesScreen categories={categories} onAddCat={() => setShowAddCat(true)} />}
        </main>

        <nav className="md:hidden fixed bottom-0 inset-x-0 glass-panel border-t border-white/50 flex px-1.5 py-2 gap-1">
          {NAV.map(({ id, label, icon: Icon }) => (
            <button key={id} onClick={() => setScreen(id)}
              className={`flex-1 flex flex-col items-center gap-1 py-1.5 rounded-xl text-[10px] font-bold transition-all ${screen === id ? "nav-item-active" : "text-neutral-500"}`}>
              <Icon className="w-4.5 h-4.5" />
              {label}
            </button>
          ))}
        </nav>
      </div>

      {showAddTx && <AddTransactionModal categories={categories} onClose={() => setShowAddTx(false)} onSubmit={createTransaction} />}
      {showAddCat && <AddCategoryModal onClose={() => setShowAddCat(false)} onSubmit={createCategory} />}
      {showAddInv && <AddInvestmentModal onClose={() => setShowAddInv(false)} onSubmit={createInvestment} />}
      {editingInv && <EditPriceModal investment={editingInv} onClose={() => setEditingInv(null)} onSubmit={(price) => updateInvestmentPrice(editingInv.id, price)} />}
      {showAddGoal && <AddGoalModal onClose={() => setShowAddGoal(false)} onSubmit={createGoal} />}
      {contributingGoal && <ContributeModal goal={contributingGoal} onClose={() => setContributingGoal(null)} onSubmit={(amount) => contributeToGoal(contributingGoal.id, amount)} />}
      {gamblingNudge && <GamblingNudgeModal nudge={gamblingNudge} onClose={() => setGamblingNudge(null)} />}

      <Toast text={toast} />
    </div>
  );
}

function Field({ label, children }) {
  return <div><label className="text-xs font-bold text-neutral-600 block mb-1.5">{label}</label>{children}</div>;
}

function ErrorBanner({ text, className = "" }) {
  return (
    <div className={`flex items-start gap-2 text-rose-800 bg-rose-100/70 backdrop-blur border border-rose-200 rounded-xl px-3 py-2 text-xs font-bold ${className}`}>
      <AlertCircle className="w-3.5 h-3.5 mt-0.5 shrink-0" /><span>{text}</span>
    </div>
  );
}

function SectionHeader({ title, action }) {
  return (
    <div className="flex items-center justify-between mb-4">
      <h1 className="fg-display text-xl font-bold text-neutral-900">{title}</h1>
      {action}
    </div>
  );
}

function AddButton({ onClick, label, primary }) {
  return (
    <button onClick={onClick} className={`${primary ? "btn-primary" : "btn-glass text-neutral-800"} flex items-center gap-1.5 text-xs px-3 py-2`}>
      <Plus className="w-3.5 h-3.5" /> {label}
    </button>
  );
}

function ChartCard({ title, children, empty }) {
  return (
    <div className="glass-card p-4 mb-6">
      <p className="text-xs font-bold text-neutral-500 uppercase tracking-wide mb-3">{title}</p>
      {empty ? <p className="text-sm text-neutral-400 font-semibold text-center py-10">Ainda sem dados suficientes para mostrar aqui.</p> : children}
    </div>
  );
}

function DonutChart({ data }) {
  return (
    <ResponsiveContainer width="100%" height={200}>
      <PieChart>
        <Pie data={data} dataKey="value" nameKey="name" innerRadius={45} outerRadius={75} paddingAngle={3}>
          {data.map((_, i) => <Cell key={i} fill={CHART_COLORS[i % CHART_COLORS.length]} stroke="rgba(255,255,255,0.8)" strokeWidth={2} />)}
        </Pie>
        <Tooltip formatter={(v) => money(v)} contentStyle={{ borderRadius: 12, border: "1px solid rgba(255,255,255,0.8)", fontWeight: 700, backdropFilter: "blur(10px)" }} />
        <Legend wrapperStyle={{ fontSize: 11, fontWeight: 700 }} />
      </PieChart>
    </ResponsiveContainer>
  );
}

function Dashboard({ income, expense, balance, currentValue, gain, gainPct, transactions, categories, goals, onAddTx, mood, monthlyData, expenseByCategory }) {
  const catName = (id) => categories.find((c) => c.id === id)?.name || "Sem categoria";
  const topGoal = goals[0];
  return (
    <div>
      <div className="flex items-center gap-3 mb-5">
        <Mascot mood={mood} size={48} />
        <div>
          <p className="fg-display text-xl font-bold text-neutral-900">
            {mood === "happy" ? "Tá voando" : mood === "worried" ? "Vamos com calma" : "Tudo em ordem"}
          </p>
          <p className="text-xs text-neutral-500 font-bold">Seu resumo financeiro</p>
        </div>
      </div>

      <div className="grid grid-cols-3 gap-2 mb-3">
        <StatCard label="Saldo" value={money(balance)} />
        <StatCard label="Receitas" value={money(income)} tone="up" />
        <StatCard label="Despesas" value={money(expense)} tone="down" />
      </div>

      <div className="glass-card px-4 py-3 flex items-center justify-between mb-3">
        <div>
          <p className="text-xs uppercase tracking-wide text-neutral-500 font-bold mb-0.5">Carteira de investimentos</p>
          <p className="text-base font-mono font-extrabold text-neutral-900">{money(currentValue)}</p>
        </div>
        {currentValue > 0 && (
          <span className={`text-xs font-mono font-extrabold flex items-center gap-1 ${gain >= 0 ? "text-emerald-600" : "text-rose-600"}`}>
            {gain >= 0 ? <ArrowUpRight className="w-4 h-4" /> : <ArrowDownRight className="w-4 h-4" />}
            {pct(gainPct)}
          </span>
        )}
      </div>

      {topGoal && (
        <div className="glass-card px-4 py-3 mb-6">
          <div className="flex items-center justify-between mb-2">
            <p className="text-sm font-bold text-neutral-800">{topGoal.emoji} {topGoal.name}</p>
            <p className="text-xs font-mono font-bold text-neutral-500">{Math.min(100, (topGoal.current_amount / topGoal.target_amount) * 100).toFixed(0)}%</p>
          </div>
          <div className="goal-track"><div className="goal-fill" style={{ width: `${Math.min(100, (topGoal.current_amount / topGoal.target_amount) * 100)}%` }} /></div>
          <p className="text-xs text-neutral-500 font-semibold mt-1.5">{money(topGoal.current_amount)} de {money(topGoal.target_amount)}</p>
        </div>
      )}

      <ChartCard title="Receitas x despesas (últimos meses)" empty={monthlyData.length === 0}>
        <ResponsiveContainer width="100%" height={200}>
          <BarChart data={monthlyData}>
            <CartesianGrid strokeDasharray="4 4" stroke="rgba(120,90,200,0.12)" />
            <XAxis dataKey="label" tick={{ fontSize: 11, fontWeight: 700 }} axisLine={false} tickLine={false} />
            <YAxis tick={{ fontSize: 10, fontWeight: 600 }} axisLine={false} tickLine={false} width={40} />
            <Tooltip formatter={(v) => money(v)} contentStyle={{ borderRadius: 12, border: "1px solid rgba(255,255,255,0.8)", fontWeight: 700 }} />
            <Bar dataKey="income" name="Receitas" fill="#10B981" radius={[6, 6, 0, 0]} />
            <Bar dataKey="expense" name="Despesas" fill="#F43F5E" radius={[6, 6, 0, 0]} />
          </BarChart>
        </ResponsiveContainer>
      </ChartCard>

      <ChartCard title="Despesas por categoria" empty={expenseByCategory.length === 0}>
        <DonutChart data={expenseByCategory} />
      </ChartCard>

      <SectionHeader title="Últimas transações" action={<AddButton onClick={onAddTx} label="Nova" />} />
      <TransactionList transactions={transactions.slice(0, 6)} catName={catName} emptyHint="Adicione sua primeira transação para começar a acompanhar seu saldo." />
    </div>
  );
}

function TransactionsScreen({ transactions, categories, onAddTx }) {
  const [typeFilter, setTypeFilter] = useState("all");
  const [catFilter, setCatFilter] = useState("all");
  const [dateFrom, setDateFrom] = useState("");
  const [dateTo, setDateTo] = useState("");
  const [showFilters, setShowFilters] = useState(false);
  const catName = (id) => categories.find((c) => c.id === id)?.name || "Sem categoria";

  const filtered = transactions.filter((t) => {
    if (typeFilter !== "all" && t.type !== typeFilter) return false;
    if (catFilter !== "all" && String(t.category_id) !== catFilter) return false;
    if (dateFrom && t.occurred_at.slice(0, 10) < dateFrom) return false;
    if (dateTo && t.occurred_at.slice(0, 10) > dateTo) return false;
    return true;
  });
  const activeFilterCount = [typeFilter !== "all", catFilter !== "all", !!dateFrom, !!dateTo].filter(Boolean).length;

  return (
    <div>
      <SectionHeader title="Transações" action={<AddButton onClick={onAddTx} label="Nova transação" primary />} />
      <button onClick={() => setShowFilters((s) => !s)} className="btn-glass flex items-center gap-1.5 text-xs text-neutral-800 px-3 py-2 mb-3">
        <SlidersHorizontal className="w-3.5 h-3.5" /> Filtros {activeFilterCount > 0 && `(${activeFilterCount})`}
      </button>
      {showFilters && (
        <div className="glass-card p-4 mb-4 grid grid-cols-2 gap-3 pop-in">
          <Field label="Tipo">
            <select value={typeFilter} onChange={(e) => setTypeFilter(e.target.value)} className="glass-input">
              <option value="all">Todos</option><option value="income">Receita</option><option value="expense">Despesa</option>
            </select>
          </Field>
          <Field label="Categoria">
            <select value={catFilter} onChange={(e) => setCatFilter(e.target.value)} className="glass-input">
              <option value="all">Todas</option>
              {categories.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
            </select>
          </Field>
          <Field label="De"><input type="date" value={dateFrom} onChange={(e) => setDateFrom(e.target.value)} className="glass-input" /></Field>
          <Field label="Até"><input type="date" value={dateTo} onChange={(e) => setDateTo(e.target.value)} className="glass-input" /></Field>
        </div>
      )}
      <TransactionList transactions={filtered} catName={catName} emptyHint={transactions.length === 0 ? "Nenhuma transação ainda. Adicione a primeira para começar." : "Nenhuma transação bate com esses filtros."} />
    </div>
  );
}

function TransactionList({ transactions, catName, emptyHint }) {
  if (transactions.length === 0) return <EmptyState text={emptyHint} />;
  return (
    <div className="glass-card divide-y divide-white/50 overflow-hidden">
      {transactions.map((t) => (
        <div key={t.id} className="flex items-center gap-3 px-4 py-3">
          <div className={`w-8 h-8 rounded-full flex items-center justify-center shrink-0 ${t.type === "income" ? "bg-emerald-100 text-emerald-600" : "bg-rose-100 text-rose-600"}`}>
            {t.type === "income" ? <ArrowUpRight className="w-4 h-4" /> : <ArrowDownRight className="w-4 h-4" />}
          </div>
          <div className="min-w-0 flex-1">
            <p className="text-sm font-bold text-neutral-900 truncate">{t.description || catName(t.category_id)}</p>
            <p className="text-xs text-neutral-500 font-semibold">{catName(t.category_id)} · {dateBR(t.occurred_at)}</p>
          </div>
          <span className={`text-sm font-mono font-extrabold shrink-0 tabular-nums ${t.type === "income" ? "text-emerald-600" : "text-rose-600"}`}>
            {t.type === "income" ? "+" : "−"}{money(t.amount)}
          </span>
        </div>
      ))}
    </div>
  );
}

function GoalsScreen({ goals, onAdd, onContribute, onDelete }) {
  return (
    <div>
      <SectionHeader title="Metas" action={<AddButton onClick={onAdd} label="Nova meta" primary />} />
      {goals.length === 0 ? (
        <EmptyState text="Nenhuma meta ainda. Crie uma e comece a acompanhar seu progresso." />
      ) : (
        <div className="grid gap-3">
          {goals.map((g) => {
            const p = Math.min(100, (g.current_amount / g.target_amount) * 100);
            const done = g.current_amount >= g.target_amount;
            return (
              <div key={g.id} className="glass-card p-4">
                <div className="flex items-center justify-between mb-2">
                  <p className="text-sm font-bold text-neutral-900 flex items-center gap-2">
                    <span className="text-lg">{g.emoji}</span> {g.name} {done && <span className="text-xs">🎉</span>}
                  </p>
                  <div className="flex items-center gap-1">
                    <button onClick={() => onContribute(g)} className="btn-glass p-1.5 text-neutral-700"><Plus className="w-3.5 h-3.5" /></button>
                    <button onClick={() => onDelete(g.id)} className="btn-glass p-1.5 text-neutral-700 hover:text-rose-600"><Trash2 className="w-3.5 h-3.5" /></button>
                  </div>
                </div>
                <div className="goal-track"><div className="goal-fill" style={{ width: `${p}%` }} /></div>
                <div className="flex items-center justify-between mt-1.5">
                  <p className="text-xs text-neutral-500 font-semibold">{money(g.current_amount)} de {money(g.target_amount)}</p>
                  <p className="text-xs font-mono font-bold text-violet-600">{p.toFixed(0)}%</p>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

function InvestmentsScreen({ investments, invested, currentValue, gain, gainPct, onAdd, onEditPrice, onDelete, allocationData }) {
  return (
    <div>
      <SectionHeader title="Investimentos" action={<AddButton onClick={onAdd} label="Novo ativo" primary />} />
      <div className="grid grid-cols-3 gap-2 mb-6">
        <StatCard label="Investido" value={money(invested)} />
        <StatCard label="Valor atual" value={money(currentValue)} />
        <StatCard label="Resultado" value={`${gain >= 0 ? "+" : ""}${money(gain)}`} tone={gain >= 0 ? "up" : "down"} sub={investments.length > 0 ? pct(gainPct) : null} />
      </div>
      {investments.length > 0 && (
        <ChartCard title="Alocação da carteira" empty={allocationData.length === 0}><DonutChart data={allocationData} /></ChartCard>
      )}
      {investments.length === 0 ? (
        <EmptyState text="Nenhum ativo cadastrado. Adicione moedas, FIIs ou outros ativos que você já possui." />
      ) : (
        <div className="glass-card divide-y divide-white/50 overflow-hidden">
          {investments.map((inv) => {
            const total = inv.quantity * inv.current_price;
            const investedInv = inv.quantity * inv.avg_price;
            const g = total - investedInv;
            const gPct = investedInv > 0 ? (g / investedInv) * 100 : 0;
            return (
              <div key={inv.id} className="px-4 py-3 flex items-center gap-3">
                <span className="text-xl shrink-0">{ASSET_EMOJI[inv.asset_type] || "💼"}</span>
                <div className="min-w-0 flex-1">
                  <div className="flex items-center gap-2">
                    <p className="text-sm font-bold text-neutral-900 truncate">{inv.name}</p>
                    <span className="text-xs uppercase tracking-wide text-neutral-600 font-bold bg-white/50 border border-white/70 rounded px-1.5 py-0.5 shrink-0">
                      {ASSET_LABEL[inv.asset_type] || inv.asset_type}
                    </span>
                  </div>
                  <p className="text-xs text-neutral-500 font-mono font-semibold tabular-nums">
                    {inv.quantity} × {money(inv.current_price, inv.currency)}
                    <span className="text-neutral-400"> · méd. {money(inv.avg_price, inv.currency)}</span>
                  </p>
                </div>
                <div className="text-right shrink-0">
                  <p className="text-sm font-mono font-extrabold text-neutral-900 tabular-nums">{money(total, inv.currency)}</p>
                  <p className={`text-xs font-mono font-bold tabular-nums ${g >= 0 ? "text-emerald-600" : "text-rose-600"}`}>{pct(gPct)}</p>
                </div>
                <div className="flex items-center gap-1 shrink-0">
                  <button onClick={() => onEditPrice(inv)} className="btn-glass p-1.5"><Pencil className="w-3.5 h-3.5" /></button>
                  <button onClick={() => onDelete(inv.id)} className="btn-glass p-1.5 hover:text-rose-600"><Trash2 className="w-3.5 h-3.5" /></button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

function CategoriesScreen({ categories, onAddCat }) {
  return (
    <div>
      <SectionHeader title="Categorias" action={<AddButton onClick={onAddCat} label="Nova categoria" primary />} />
      {categories.length === 0 ? (
        <EmptyState text="Nenhuma categoria ainda. Crie a primeira antes de registrar transações." />
      ) : (
        <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
          {categories.map((c) => (
            <div key={c.id} className="glass-card px-3 py-3 flex items-center gap-2">
              <span className={`w-2 h-2 rounded-full shrink-0 ${c.type === "income" ? "bg-emerald-500" : "bg-rose-500"}`} />
              <span className="text-sm font-bold text-neutral-800 truncate">{c.name}</span>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

function StatCard({ label, value, tone, sub }) {
  const toneClass = tone === "up" ? "text-emerald-600" : tone === "down" ? "text-rose-600" : "text-neutral-900";
  return (
    <div className="glass-card px-3 py-3">
      <p className="text-xs uppercase tracking-wide text-neutral-500 font-bold mb-0.5">{label}</p>
      <p className={`text-sm font-mono font-extrabold tabular-nums ${toneClass}`}>{value}</p>
      {sub && <p className={`text-xs font-mono font-bold tabular-nums ${toneClass}`}>{sub}</p>}
    </div>
  );
}

function EmptyState({ text }) {
  return <div className="glass-card border-dashed py-10 text-center text-sm text-neutral-500 font-semibold px-6">{text}</div>;
}

function Modal({ title, onClose, children }) {
  return (
    <div className="fixed inset-0 bg-neutral-900/30 backdrop-blur-sm flex items-end md:items-center justify-center z-50 fg-root">
      <div className="glass-strong pop-in w-full md:max-w-sm rounded-t-3xl md:rounded-3xl p-5 max-h-[85vh] overflow-y-auto border border-white/60">
        <div className="flex items-center justify-between mb-4">
          <h3 className="fg-display text-base font-bold text-neutral-900">{title}</h3>
          <button onClick={onClose} className="btn-glass p-1.5"><X className="w-4 h-4" /></button>
        </div>
        {children}
      </div>
    </div>
  );
}

function TypeToggle({ value, onChange, options }) {
  return (
    <div className="flex gap-2">
      {options.map((o) => (
        <button key={o.value} type="button" onClick={() => onChange(o.value)}
          className={`flex-1 text-sm font-bold py-2 rounded-xl border transition-all ${value === o.value ? `${o.activeClass} border-transparent` : "border-white/70 bg-white/40 text-neutral-500"}`}>
          {o.label}
        </button>
      ))}
    </div>
  );
}

function AddCategoryModal({ onClose, onSubmit }) {
  const [name, setName] = useState("");
  const [type, setType] = useState("expense");
  const [busy, setBusy] = useState(false);
  async function submit(e) { e.preventDefault(); setBusy(true); await onSubmit(name, type); setBusy(false); }
  return (
    <Modal title="Nova categoria" onClose={onClose}>
      <form onSubmit={submit} className="space-y-4">
        <Field label="Nome"><input required value={name} onChange={(e) => setName(e.target.value)} placeholder="Ex: Salário, Mercado, Transporte" className="glass-input" /></Field>
        <Field label="Tipo">
          <TypeToggle value={type} onChange={setType} options={[
            { value: "income", label: "Receita", activeClass: "bg-emerald-100 text-emerald-700" },
            { value: "expense", label: "Despesa", activeClass: "bg-rose-100 text-rose-700" },
          ]} />
        </Field>
        <button type="submit" disabled={busy} className="btn-primary w-full text-sm py-3 flex items-center justify-center gap-2">
          {busy && <Loader2 className="w-4 h-4 animate-spin" />} Criar categoria
        </button>
      </form>
    </Modal>
  );
}

function AddTransactionModal({ categories, onClose, onSubmit }) {
  const [amount, setAmount] = useState("");
  const [description, setDescription] = useState("");
  const [type, setType] = useState("expense");
  const [categoryId, setCategoryId] = useState("");
  const [occurredAt, setOccurredAt] = useState(() => {
    const now = new Date(); now.setMinutes(now.getMinutes() - now.getTimezoneOffset());
    return now.toISOString().slice(0, 16);
  });
  const [busy, setBusy] = useState(false);
  const filteredCats = categories.filter((c) => c.type === type);

  async function submit(e) {
    e.preventDefault();
    if (!categoryId) return;
    setBusy(true);
    await onSubmit({ amount: parseFloat(amount), description: description || undefined, type, category_id: Number(categoryId), occurred_at: new Date(occurredAt).toISOString() });
    setBusy(false);
  }

  if (categories.length === 0) {
    return (
      <Modal title="Nova transação" onClose={onClose}>
        <p className="text-sm text-neutral-600 font-semibold flex items-start gap-2">
          <ChevronRight className="w-4 h-4 mt-0.5 shrink-0" />
          Crie uma categoria primeiro, na aba Categorias — toda transação precisa estar ligada a uma.
        </p>
      </Modal>
    );
  }

  return (
    <Modal title="Nova transação" onClose={onClose}>
      <form onSubmit={submit} className="space-y-4">
        <TypeToggle value={type} onChange={(v) => { setType(v); setCategoryId(""); }} options={[
          { value: "income", label: "Receita", activeClass: "bg-emerald-100 text-emerald-700" },
          { value: "expense", label: "Despesa", activeClass: "bg-rose-100 text-rose-700" },
        ]} />
        <Field label="Valor"><input type="number" step="0.01" required value={amount} onChange={(e) => setAmount(e.target.value)} placeholder="0,00" className="glass-input font-mono" /></Field>
        <Field label="Categoria">
          {filteredCats.length === 0 ? (
            <p className="text-xs text-neutral-500 font-semibold">Nenhuma categoria de {type === "income" ? "receita" : "despesa"} ainda. Crie uma na aba Categorias.</p>
          ) : (
            <select value={categoryId} onChange={(e) => setCategoryId(e.target.value)} className="glass-input">
              <option value="">Selecione</option>
              {filteredCats.map((c) => <option key={c.id} value={c.id}>{c.name}</option>)}
            </select>
          )}
        </Field>
        <Field label="Descrição (opcional)"><input value={description} onChange={(e) => setDescription(e.target.value)} placeholder="Ex: Pagamento mensal" className="glass-input" /></Field>
        <Field label="Data"><input type="datetime-local" required value={occurredAt} onChange={(e) => setOccurredAt(e.target.value)} className="glass-input" /></Field>
        <button type="submit" disabled={busy || !categoryId} className="btn-primary w-full text-sm py-3 flex items-center justify-center gap-2">
          {busy && <Loader2 className="w-4 h-4 animate-spin" />} Salvar transação
        </button>
      </form>
    </Modal>
  );
}

function AddInvestmentModal({ onClose, onSubmit }) {
  const [assetType, setAssetType] = useState("moeda");
  const [name, setName] = useState("");
  const [ticker, setTicker] = useState("");
  const [quantity, setQuantity] = useState("");
  const [avgPrice, setAvgPrice] = useState("");
  const [currentPrice, setCurrentPrice] = useState("");
  const [currency, setCurrency] = useState("BRL");
  const [busy, setBusy] = useState(false);

  async function submit(e) {
    e.preventDefault();
    setBusy(true);
    await onSubmit({ asset_type: assetType, name, ticker: ticker || undefined, quantity: parseFloat(quantity), avg_price: parseFloat(avgPrice), current_price: parseFloat(currentPrice), currency });
    setBusy(false);
  }

  return (
    <Modal title="Novo ativo" onClose={onClose}>
      <form onSubmit={submit} className="space-y-4">
        <Field label="Tipo de ativo">
          <select value={assetType} onChange={(e) => setAssetType(e.target.value)} className="glass-input">
            <option value="moeda">💵 Moeda estrangeira</option>
            <option value="fii">🏢 Fundo imobiliário (FII)</option>
            <option value="acao">📈 Ação</option>
            <option value="renda_fixa">🏦 Renda fixa</option>
            <option value="cripto">🪙 Criptoativo</option>
          </select>
        </Field>
        <Field label="Nome"><input required value={name} onChange={(e) => setName(e.target.value)} placeholder="Ex: Dólar Americano, HGLG11" className="glass-input" /></Field>
        <div className="grid grid-cols-2 gap-3">
          <Field label="Ticker (opcional)"><input value={ticker} onChange={(e) => setTicker(e.target.value)} placeholder="USD, HGLG11" className="glass-input" /></Field>
          <Field label="Moeda">
            <select value={currency} onChange={(e) => setCurrency(e.target.value)} className="glass-input">
              <option value="BRL">BRL</option><option value="USD">USD</option><option value="EUR">EUR</option>
            </select>
          </Field>
        </div>
        <Field label="Quantidade"><input type="number" step="any" required value={quantity} onChange={(e) => setQuantity(e.target.value)} placeholder="Ex: 500" className="glass-input font-mono" /></Field>
        <div className="grid grid-cols-2 gap-3">
          <Field label="Preço médio pago"><input type="number" step="any" required value={avgPrice} onChange={(e) => setAvgPrice(e.target.value)} placeholder="0,00" className="glass-input font-mono" /></Field>
          <Field label="Cotação atual"><input type="number" step="any" required value={currentPrice} onChange={(e) => setCurrentPrice(e.target.value)} placeholder="0,00" className="glass-input font-mono" /></Field>
        </div>
        <button type="submit" disabled={busy} className="btn-primary w-full text-sm py-3 flex items-center justify-center gap-2">
          {busy && <Loader2 className="w-4 h-4 animate-spin" />} Adicionar ativo
        </button>
      </form>
    </Modal>
  );
}

function EditPriceModal({ investment, onClose, onSubmit }) {
  const [price, setPrice] = useState(String(investment.current_price));
  const [busy, setBusy] = useState(false);
  async function submit(e) { e.preventDefault(); setBusy(true); await onSubmit(parseFloat(price)); setBusy(false); }
  return (
    <Modal title={`Atualizar cotação — ${investment.name}`} onClose={onClose}>
      <form onSubmit={submit} className="space-y-4">
        <Field label="Nova cotação atual"><input type="number" step="any" required autoFocus value={price} onChange={(e) => setPrice(e.target.value)} className="glass-input font-mono" /></Field>
        <button type="submit" disabled={busy} className="btn-primary w-full text-sm py-3 flex items-center justify-center gap-2">
          {busy && <Loader2 className="w-4 h-4 animate-spin" />} Salvar cotação
        </button>
      </form>
    </Modal>
  );
}

function AddGoalModal({ onClose, onSubmit }) {
  const [emoji, setEmoji] = useState("🎯");
  const [name, setName] = useState("");
  const [targetAmount, setTargetAmount] = useState("");
  const [targetDate, setTargetDate] = useState("");
  const [busy, setBusy] = useState(false);

  async function submit(e) {
    e.preventDefault();
    setBusy(true);
    await onSubmit({
      emoji, name, target_amount: parseFloat(targetAmount),
      target_date: targetDate ? new Date(targetDate).toISOString() : undefined,
    });
    setBusy(false);
  }

  return (
    <Modal title="Nova meta" onClose={onClose}>
      <form onSubmit={submit} className="space-y-4">
        <Field label="Ícone">
          <div className="flex flex-wrap gap-2">
            {GOAL_EMOJIS.map((em) => (
              <button key={em} type="button" onClick={() => setEmoji(em)}
                className={`w-9 h-9 rounded-xl flex items-center justify-center text-lg border transition-all ${emoji === em ? "nav-item-active border-transparent" : "border-white/70 bg-white/40"}`}>
                {em}
              </button>
            ))}
          </div>
        </Field>
        <Field label="Nome da meta"><input required value={name} onChange={(e) => setName(e.target.value)} placeholder="Ex: Viagem pro Japão" className="glass-input" /></Field>
        <Field label="Valor alvo"><input type="number" step="any" required value={targetAmount} onChange={(e) => setTargetAmount(e.target.value)} placeholder="0,00" className="glass-input font-mono" /></Field>
        <Field label="Data alvo (opcional)"><input type="date" value={targetDate} onChange={(e) => setTargetDate(e.target.value)} className="glass-input" /></Field>
        <button type="submit" disabled={busy} className="btn-primary w-full text-sm py-3 flex items-center justify-center gap-2">
          {busy && <Loader2 className="w-4 h-4 animate-spin" />} Criar meta
        </button>
      </form>
    </Modal>
  );
}

function ContributeModal({ goal, onClose, onSubmit }) {
  const [amount, setAmount] = useState("");
  const [busy, setBusy] = useState(false);
  async function submit(e) { e.preventDefault(); setBusy(true); await onSubmit(parseFloat(amount)); setBusy(false); }
  return (
    <Modal title={`Novo aporte — ${goal.emoji} ${goal.name}`} onClose={onClose}>
      <form onSubmit={submit} className="space-y-4">
        <Field label="Quanto você quer adicionar?"><input type="number" step="any" required autoFocus value={amount} onChange={(e) => setAmount(e.target.value)} placeholder="0,00" className="glass-input font-mono" /></Field>
        <button type="submit" disabled={busy} className="btn-primary w-full text-sm py-3 flex items-center justify-center gap-2">
          {busy && <Loader2 className="w-4 h-4 animate-spin" />} Registrar aporte
        </button>
      </form>
    </Modal>
  );
}

function GamblingNudgeModal({ nudge, onClose }) {
  const [rate, setRate] = useState(10);
  const { amount } = nudge;
  const lump1y = futureValueLump(amount, rate, 1);
  const lump5y = futureValueLump(amount, rate, 5);
  const annuity1y = futureValueMonthlyAnnuity(amount, rate, 12);
  const annuity5y = futureValueMonthlyAnnuity(amount, rate, 60);

  return (
    <Modal title="Antes de seguir..." onClose={onClose}>
      <div className="space-y-4">
        <div className="glass-card bg-amber-50/60 px-4 py-3">
          <p className="text-sm font-semibold text-neutral-800">
            Notei que essa despesa de <span className="font-mono font-extrabold">{money(amount)}</span> parece ser com aposta.
            Sem julgamento — só uma comparação rápida.
          </p>
        </div>
        <Field label="Taxa de rendimento estimada (% ao ano)">
          <input type="number" step="0.1" value={rate} onChange={(e) => setRate(parseFloat(e.target.value) || 0)} className="glass-input font-mono" />
        </Field>
        <div>
          <p className="text-xs font-bold text-neutral-500 uppercase tracking-wide mb-2">Se você investisse esse valor uma única vez</p>
          <div className="grid grid-cols-2 gap-2">
            <StatCard label="Em 1 ano" value={money(lump1y)} tone="up" />
            <StatCard label="Em 5 anos" value={money(lump5y)} tone="up" />
          </div>
        </div>
        <div>
          <p className="text-xs font-bold text-neutral-500 uppercase tracking-wide mb-2">Se {money(amount)} virasse um hábito mensal investido</p>
          <div className="grid grid-cols-2 gap-2">
            <StatCard label="Em 1 ano" value={money(annuity1y)} />
            <StatCard label="Em 5 anos" value={money(annuity5y)} />
          </div>
        </div>
        <p className="text-xs text-neutral-500 font-semibold leading-relaxed">
          Estimativa simples com juros compostos à taxa que você definiu — não é garantia de rendimento nem recomendação de investimento.
        </p>
        <button onClick={onClose} className="btn-primary w-full text-sm py-3">Entendi</button>
      </div>
    </Modal>
  );
}
