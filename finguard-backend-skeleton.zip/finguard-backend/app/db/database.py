from sqlalchemy import create_engine
from sqlalchemy.orm import declarative_base, sessionmaker

from app.core.config import settings

# connect_args é necessário só para SQLite: por padrão, o SQLite só permite
# que a thread que abriu a conexão a use. Como o FastAPI atende cada
# requisição numa thread do pool, isso evita o erro
# "SQLite objects created in a thread can only be used in that same thread".
connect_args = {"check_same_thread": False} if settings.database_url.startswith("sqlite") else {}

engine = create_engine(settings.database_url, connect_args=connect_args)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()


def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()
