from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.api.deps import get_current_user
from app.db.database import get_db
from app.models.goal import Goal
from app.models.user import User
from app.schemas.goal import GoalContribute, GoalCreate, GoalRead

router = APIRouter(prefix="/goals", tags=["goals"])


def _get_owned_goal(goal_id: int, db: Session, user: User) -> Goal:
    goal = db.query(Goal).filter(Goal.id == goal_id, Goal.user_id == user.id).first()
    if not goal:
        raise HTTPException(status_code=404, detail="Meta não encontrada")
    return goal


@router.get("/", response_model=list[GoalRead])
def list_goals(db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    return db.query(Goal).filter(Goal.user_id == current_user.id).all()


@router.post("/", response_model=GoalRead, status_code=201)
def create_goal(
    goal_in: GoalCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    goal = Goal(**goal_in.model_dump(), user_id=current_user.id)
    db.add(goal)
    db.commit()
    db.refresh(goal)
    return goal


@router.post("/{goal_id}/contribute", response_model=GoalRead)
def contribute_to_goal(
    goal_id: int,
    contribution: GoalContribute,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    goal = _get_owned_goal(goal_id, db, current_user)
    goal.current_amount += contribution.amount
    db.commit()
    db.refresh(goal)
    return goal


@router.delete("/{goal_id}", status_code=204)
def delete_goal(
    goal_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    goal = _get_owned_goal(goal_id, db, current_user)
    db.delete(goal)
    db.commit()
    return None
