from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session

from app.api.deps import get_current_user
from app.db.database import get_db
from app.models.investment import Investment
from app.models.user import User
from app.schemas.investment import InvestmentCreate, InvestmentRead, InvestmentUpdatePrice

router = APIRouter(prefix="/investments", tags=["investments"])


def _get_owned_investment(investment_id: int, db: Session, user: User) -> Investment:
    investment = (
        db.query(Investment)
        .filter(Investment.id == investment_id, Investment.user_id == user.id)
        .first()
    )
    if not investment:
        raise HTTPException(status_code=404, detail="Investimento não encontrado")
    return investment


@router.get("/", response_model=list[InvestmentRead])
def list_investments(db: Session = Depends(get_db), current_user: User = Depends(get_current_user)):
    return db.query(Investment).filter(Investment.user_id == current_user.id).all()


@router.post("/", response_model=InvestmentRead, status_code=201)
def create_investment(
    investment_in: InvestmentCreate,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    investment = Investment(**investment_in.model_dump(), user_id=current_user.id)
    db.add(investment)
    db.commit()
    db.refresh(investment)
    return investment


@router.put("/{investment_id}/price", response_model=InvestmentRead)
def update_price(
    investment_id: int,
    price_in: InvestmentUpdatePrice,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    investment = _get_owned_investment(investment_id, db, current_user)
    investment.current_price = price_in.current_price
    db.commit()
    db.refresh(investment)
    return investment


@router.delete("/{investment_id}", status_code=204)
def delete_investment(
    investment_id: int,
    db: Session = Depends(get_db),
    current_user: User = Depends(get_current_user),
):
    investment = _get_owned_investment(investment_id, db, current_user)
    db.delete(investment)
    db.commit()
    return None
