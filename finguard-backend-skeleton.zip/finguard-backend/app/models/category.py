from sqlalchemy import Column, ForeignKey, Integer, String
from sqlalchemy.orm import relationship

from app.db.database import Base


class Category(Base):
    __tablename__ = "categories"

    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, nullable=False)
    type = Column(String, nullable=False)  # "income" ou "expense"
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)

    transactions = relationship("Transaction", back_populates="category")
