from sqlalchemy import Column, DateTime, Float, ForeignKey, Integer, String, func

from app.db.database import Base


class Investment(Base):
    __tablename__ = "investments"

    id = Column(Integer, primary_key=True, index=True)
    user_id = Column(Integer, ForeignKey("users.id"), nullable=False)

    asset_type = Column(String, nullable=False)  # "moeda", "fii", "acao", "renda_fixa", "cripto"
    name = Column(String, nullable=False)
    ticker = Column(String, nullable=True)

    quantity = Column(Float, nullable=False)
    avg_price = Column(Float, nullable=False)
    current_price = Column(Float, nullable=False)
    currency = Column(String, nullable=False, default="BRL")

    created_at = Column(DateTime(timezone=True), server_default=func.now())
    updated_at = Column(DateTime(timezone=True), server_default=func.now(), onupdate=func.now())
