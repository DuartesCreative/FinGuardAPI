from datetime import datetime
from typing import Optional

from pydantic import BaseModel


class GoalBase(BaseModel):
    name: str
    emoji: str = "🎯"
    target_amount: float
    target_date: Optional[datetime] = None


class GoalCreate(GoalBase):
    pass


class GoalContribute(BaseModel):
    amount: float


class GoalRead(GoalBase):
    id: int
    current_amount: float
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True
