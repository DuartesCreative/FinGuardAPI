from datetime import datetime
from typing import Optional

from pydantic import BaseModel


class InvestmentBase(BaseModel):
    asset_type: str
    name: str
    ticker: Optional[str] = None
    quantity: float
    avg_price: float
    current_price: float
    currency: str = "BRL"


class InvestmentCreate(InvestmentBase):
    pass


class InvestmentUpdatePrice(BaseModel):
    current_price: float


class InvestmentRead(InvestmentBase):
    id: int
    created_at: datetime
    updated_at: datetime

    class Config:
        from_attributes = True
