# FinGuard API — backend (sem Docker)

FastAPI + SQLite + JWT. Cobre: usuários, categorias, transações, investimentos e metas de economia.

**Sem Docker, sem Postgres separado.** O banco é um arquivo (`finguard.db`) criado automaticamente na primeira vez que a API roda.

## Rodar localmente

```bash
python -m venv venv
venv\Scripts\activate          # Windows
pip install -r requirements.txt
copy .env.example .env         # ajuste o SECRET_KEY
uvicorn app.main:app --reload
```

Abra `http://localhost:8000/docs`.

## Estrutura

```
app/
  core/       -> config (.env) e segurança (hash de senha, JWT)
  db/         -> conexão com o banco (SQLite)
  models/     -> tabelas (user, category, transaction, investment, goal)
  schemas/    -> validação de entrada/saída (Pydantic)
  api/
    deps.py     -> lê o token e identifica o usuário logado
    routes/     -> auth, users, categories, transactions, investments, goals
  main.py     -> registra tudo e sobe o servidor
```

## Rotas

- `POST /auth/register`, `POST /auth/login`
- `GET /users/me`
- `GET/POST /categories/`
- `GET/POST /transactions/`
- `GET/POST /investments/`, `PUT /investments/{id}/price`, `DELETE /investments/{id}`
- `GET/POST /goals/`, `POST /goals/{id}/contribute`, `DELETE /goals/{id}`

## Sobre o banco de dados

O arquivo `finguard.db` aparece na própria pasta do projeto depois do primeiro `uvicorn app.main:app --reload`. Ele guarda todos os seus dados — **não apague esse arquivo** a menos que queira zerar tudo. Ele sincroniza pelo Google Drive normalmente (é só um arquivo), diferente do antigo volume do Docker.

## Se um dia precisar voltar para PostgreSQL

Basta trocar `DATABASE_URL` no `.env` para uma URL do Postgres e instalar `psycopg2-binary`. O resto do código (models, rotas) não muda — é a vantagem de usar SQLAlchemy.
